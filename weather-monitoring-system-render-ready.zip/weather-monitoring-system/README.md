# Weather Monitoring System (C++ OOP + Website)

A responsive dark dashboard with an HTML/CSS/JavaScript frontend and a C++ backend. The backend fetches live current conditions from the free Open-Meteo geocoding and forecast APIs. No API key is required.

## Features
- Search for a city
- Live temperature, apparent temperature, humidity, wind speed and weather condition
- Responsive dark dashboard
- C++ classes (`WeatherData`, `HttpClient`, `WeatherService`) demonstrate encapsulation and object-oriented design
- JSON API endpoint: `/api/weather?city=Tenkasi`

## Requirements
- C++17 compiler
- CMake 3.20+
- Git
- libcurl development package
- Internet connection (CMake downloads two small header-only dependencies on first configure)

### Windows
1. Install Visual Studio Build Tools with the **Desktop development with C++** workload.
2. Install CMake and Git.
3. Install vcpkg and libcurl:
   ```powershell
   git clone https://github.com/microsoft/vcpkg $env:USERPROFILE\vcpkg
   & "$env:USERPROFILE\vcpkg\bootstrap-vcpkg.bat"
   & "$env:USERPROFILE\vcpkg\vcpkg.exe" install curl:x64-windows
   ```
4. Open PowerShell in this project folder and run:
   ```powershell
   cmake -S . -B build -DCMAKE_TOOLCHAIN_FILE="$env:USERPROFILE\vcpkg\scripts\buildsystems\vcpkg.cmake"
   cmake --build build --config Release
   .\build\Release\weather_server.exe
   ```
   If using a single-configuration generator, run `.\build\weather_server.exe` instead.

### Ubuntu / Debian
Install dependencies:
```bash
sudo apt update
sudo apt install -y build-essential cmake git libcurl4-openssl-dev
cmake -S . -B build
cmake --build build -j
./build/weather_server
```

## Open the website
Keep the server terminal running and visit:

http://localhost:8080

Search for a city such as Tenkasi, Chennai, Madurai or London.

## Test the backend directly
Open this URL in a browser:

http://localhost:8080/api/weather?city=Tenkasi

It should return JSON weather data.

## Project structure
```text
weather-monitoring-system/
├── CMakeLists.txt
├── README.md
├── src/
│   └── main.cpp
└── public/
    ├── index.html
    ├── style.css
    └── script.js
```

## OOP concepts for your viva
- **Class and Object:** `WeatherData`, `HttpClient`, and `WeatherService` are classes; objects are created to manage weather data and API work.
- **Encapsulation:** weather fields and service implementation are grouped inside classes; `WeatherService` exposes `getCurrentWeather()`.
- **Abstraction:** the frontend asks the backend for `/api/weather`; it does not need to know how geocoding and HTTP requests work.
- **Composition:** `WeatherService` uses the HTTP helper to retrieve API responses.

## Data source and limitations
Weather is retrieved from Open-Meteo:
- Geocoding: https://geocoding-api.open-meteo.com/
- Forecast/current conditions: https://open-meteo.com/

This is live API data, not a physical sensor reading. The dashboard displays the latest current observation returned by the provider. Internet access is required.


## Publish online (Render using Docker)
The repository includes a `Dockerfile` for deploying the C++ backend and website together.

1. Create a GitHub repository and upload all project files (keep `Dockerfile` in the root folder).
2. Sign in to Render and choose **New → Web Service**.
3. Connect the GitHub repository containing this project.
4. Set **Language** to **Docker** and keep the Dockerfile path as `./Dockerfile`.
5. Choose an available plan and click **Deploy**.
6. When deployment succeeds, open the public `https://<service-name>.onrender.com` URL shown in Render. Share that link with your teacher.

The server reads Render's `PORT` environment variable and binds to `0.0.0.0`, as required for public web services. Free web services may sleep after a period without visits, so the first visit after inactivity can take a little time.
