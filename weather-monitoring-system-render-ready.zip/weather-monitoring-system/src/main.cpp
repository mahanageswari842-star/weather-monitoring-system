#include <iostream>
#include <string>
#include <stdexcept>
#include <cstdlib>
#include <curl/curl.h>
#include <httplib.h>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

// OOP model: keeps the weather values together in one object.
class WeatherData {
public:
    std::string city, country, description, icon;
    double temperature = 0, feelsLike = 0, humidity = 0, windSpeed = 0;
    int weatherCode = 0;

    json toJson() const {
        return {
            {"city", city}, {"country", country},
            {"description", description}, {"icon", icon},
            {"temperature", temperature}, {"feelsLike", feelsLike},
            {"humidity", humidity}, {"windSpeed", windSpeed},
            {"weatherCode", weatherCode}
        };
    }
};

// Small HTTP client helper for calling the public Open-Meteo endpoints.
class HttpClient {
public:
    static size_t writeCallback(void* contents, size_t size, size_t nmemb, void* userp) {
        auto* output = static_cast<std::string*>(userp);
        output->append(static_cast<char*>(contents), size * nmemb);
        return size * nmemb;
    }

    static std::string get(const std::string& url) {
        CURL* curl = curl_easy_init();
        if (!curl) throw std::runtime_error("Could not initialize HTTP client.");

        std::string response;
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 15L);
        curl_easy_setopt(curl, CURLOPT_USERAGENT, "WeatherMonitoringSystem/1.0");

        CURLcode result = curl_easy_perform(curl);
        long status = 0;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &status);
        curl_easy_cleanup(curl);

        if (result != CURLE_OK || status < 200 || status >= 300)
            throw std::runtime_error("Weather provider request failed. Check internet connection and try again.");
        return response;
    }
};

class WeatherService {
private:
    static std::string encode(const std::string& value) {
        CURL* curl = curl_easy_init();
        if (!curl) return value;
        char* escaped = curl_easy_escape(curl, value.c_str(), static_cast<int>(value.size()));
        std::string result = escaped ? escaped : value;
        if (escaped) curl_free(escaped);
        curl_easy_cleanup(curl);
        return result;
    }

    static std::string descriptionFor(int code) {
        if (code == 0) return "Clear sky";
        if (code <= 3) return "Partly cloudy";
        if (code == 45 || code == 48) return "Fog";
        if (code >= 51 && code <= 57) return "Drizzle";
        if (code >= 61 && code <= 67) return "Rain";
        if (code >= 71 && code <= 77) return "Snow";
        if (code >= 80 && code <= 82) return "Rain showers";
        if (code >= 85 && code <= 86) return "Snow showers";
        if (code >= 95) return "Thunderstorm";
        return "Variable conditions";
    }

public:
    // Encapsulation: API lookup and conversion are handled inside this service.
    WeatherData getCurrentWeather(const std::string& cityName) {
        const std::string geoUrl =
            "https://geocoding-api.open-meteo.com/v1/search?name=" +
            encode(cityName) + "&count=1&language=en&format=json";

        json geo = json::parse(HttpClient::get(geoUrl));
        if (!geo.contains("results") || geo["results"].empty())
            throw std::runtime_error("City not found. Check the spelling and try again.");

        const auto place = geo["results"][0];
        double lat = place.at("latitude").get<double>();
        double lon = place.at("longitude").get<double>();

        const std::string weatherUrl =
            "https://api.open-meteo.com/v1/forecast?latitude=" +
            std::to_string(lat) + "&longitude=" + std::to_string(lon) +
            "&current=temperature_2m,relative_humidity_2m,apparent_temperature,"
            "is_day,precipitation,weather_code,wind_speed_10m&timezone=auto";

        json response = json::parse(HttpClient::get(weatherUrl));
        const auto current = response.at("current");

        WeatherData data;
        data.city = place.value("name", cityName);
        data.country = place.value("country", "");
        data.temperature = current.value("temperature_2m", 0.0);
        data.feelsLike = current.value("apparent_temperature", 0.0);
        data.humidity = current.value("relative_humidity_2m", 0.0);
        data.windSpeed = current.value("wind_speed_10m", 0.0);
        data.weatherCode = current.value("weather_code", 0);
        data.description = descriptionFor(data.weatherCode);
        data.icon = (data.weatherCode == 0) ? "sun" :
                    (data.weatherCode >= 95) ? "storm" :
                    (data.weatherCode >= 61 && data.weatherCode <= 82) ? "rain" : "cloud";
        return data;
    }
};

int main() {
    curl_global_init(CURL_GLOBAL_DEFAULT);

    httplib::Server server;
    WeatherService weatherService;

    server.Get("/api/weather", [&](const httplib::Request& req, httplib::Response& res) {
        res.set_header("Access-Control-Allow-Origin", "*");
        if (!req.has_param("city") || req.get_param_value("city").empty()) {
            res.status = 400;
            res.set_content(R"({"error":"Please enter a city name."})", "application/json");
            return;
        }

        try {
            WeatherData weather = weatherService.getCurrentWeather(req.get_param_value("city"));
            res.set_content(weather.toJson().dump(2), "application/json");
        } catch (const std::exception& ex) {
            res.status = 502;
            json error = {{"error", ex.what()}};
            res.set_content(error.dump(), "application/json");
        }
    });

    // Serve the website from the public folder.
    if (!server.set_mount_point("/", "./public")) {
        std::cerr << "Could not mount ./public. Run the server from the project folder.\n";
        return 1;
    }

    std::cout << "Weather Monitoring System running at http://localhost:8080\n";
    std::cout << "Press Ctrl+C to stop.\n";
    server.listen("0.0.0.0", 8080);

    curl_global_cleanup();
    return 0;
}
