const form = document.getElementById("searchForm");
const cityInput = document.getElementById("cityInput");
const message = document.getElementById("message");

function setMessage(text, isError = false) {
  message.textContent = text;
  message.className = isError ? "message error" : "message";
}

function symbolFor(icon) {
  return ({ sun: "☀", cloud: "☁", rain: "🌧", storm: "⛈" })[icon] || "☁";
}

function setText(id, value) {
  document.getElementById(id).textContent = value;
}

async function loadWeather(city) {
  if (!city.trim()) {
    setMessage("Please enter a city name.", true);
    return;
  }

  setMessage("Getting the latest weather for " + city + "...");
  try {
    const response = await fetch("/api/weather?city=" + encodeURIComponent(city.trim()));
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Unable to load weather.");

    setText("placeName", data.city + (data.country ? ", " + data.country : ""));
    setText("temperature", Math.round(data.temperature));
    setText("condition", data.description);
    setText("feelsLike", Math.round(data.feelsLike) + "°C");
    setText("feelsMetric", Math.round(data.feelsLike));
    setText("humidity", Math.round(data.humidity));
    setText("windSpeed", Number(data.windSpeed).toFixed(1));
    setText("humidityLabel", data.humidity >= 70 ? "High" : data.humidity >= 40 ? "Moderate" : "Low");
    setText("windLabel", data.windSpeed >= 25 ? "Strong" : data.windSpeed >= 10 ? "Moderate" : "Light");
    setText("weatherSymbol", symbolFor(data.icon));
    setText("detailLocation", data.city + (data.country ? ", " + data.country : ""));
    setText("weatherCode", data.weatherCode);
    setText("updatedAt", "Latest available observation · " + new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}));
    setText("weatherSummary", data.description + " conditions");
    document.getElementById("humidityMeter").style.width = Math.max(0, Math.min(100, data.humidity)) + "%";
    setMessage("Weather data updated successfully.");
  } catch (error) {
    setMessage(error.message || "Something went wrong. Please try again.", true);
  }
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  loadWeather(cityInput.value);
});

loadWeather(cityInput.value);
